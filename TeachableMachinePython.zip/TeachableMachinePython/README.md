# Teachable Machine Python — Object, Gesture & Face Studio

Aplikasi desktop Python dengan PySide6 untuk demonstrasi pembelajaran klasifikasi secara lokal:

1. **Benda:** ambil sampel dua kelas dari area tengah webcam, lalu latih model.
2. **Gestur tangan:** MediaPipe mendeteksi 21 titik tangan; ambil sampel dua gestur dan latih model.
3. **Ekspresi wajah:** MediaPipe Face Landmarker menghasilkan 52 skor blendshape; ambil sampel empat ekspresi dan latih model.
4. **Stiker + SFX:** saat prediksi gestur berpindah ke kelas lain dengan skor cukup tinggi, aplikasi menampilkan stiker reaksi dan memainkan efek suara pendek.

> Ini adalah prototipe pembelajaran, bukan salinan internal Google Teachable Machine. Model benda menggunakan HOG + histogram warna dan SVM; model tangan menggunakan 21 landmark + SVM; model wajah menggunakan 52 blendshape + SVM. Sistem wajah mengklasifikasikan **ekspresi visual yang diajarkan lewat sampel**, bukan memastikan emosi atau perasaan seseorang.

## 1. Persiapan

Direkomendasikan:

- Windows 10/11 64-bit.
- Python 3.11 64-bit. Proyek mematok MediaPipe 0.10.21 dan NumPy di bawah 2 agar kompatibel dengan Tasks API yang dipakai oleh pelacak tangan dan wajah; wheel MediaPipe 0.10.21 tersedia untuk CPython 3.11 Windows x64.
- OpenCV menggunakan paket `opencv-contrib-python` (bukan memasang `opencv-python` dan `opencv-contrib-python` bersamaan).
- Visual Studio Code dan ekstensi Python dari Microsoft.
- Webcam laptop atau webcam USB.
- Untuk mode benda: dua objek yang mudah dibedakan, misalnya helm dan botol minum.
- Untuk mode gestur: dua gestur tangan yang mudah dibedakan.
- Untuk mode wajah: volunteer yang bersedia memperagakan empat ekspresi.

## 2. Buka proyek di VS Code

1. Ekstrak ZIP proyek.
2. Buka VS Code.
3. Pilih **File → Open Folder** dan buka folder `TeachableMachinePython`.
4. Buka **Terminal → New Terminal**.

Pastikan terminal berada di folder yang berisi `app.py` dan `requirements.txt`.

## 3. Buat virtual environment

```powershell
py -3.11 -m venv .venv
```

Pilih interpreter `.venv` di VS Code melalui `Ctrl + Shift + P` → `Python: Select Interpreter`.

## 4. Instal library

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 5. Unduh model MediaPipe satu kali

Mode gestur dan ekspresi wajah membutuhkan model task MediaPipe. Pastikan komputer terhubung ke internet, lalu jalankan:

```powershell
.\.venv\Scripts\python.exe download_models.py
```

File yang diunduh:

- `models/hand_landmarker.task`
- `models/face_landmarker.task`

Sesudah file tersedia, pemakaian aplikasi tidak membutuhkan internet untuk inferensi webcam.

## 6. Jalankan aplikasi

```powershell
.\.venv\Scripts\python.exe app.py
```

Jendela **Teachable Machine Python — Object, Gesture & Face Studio** akan terbuka.

## 7. Demonstrasi — klasifikasi benda

Contoh kelas: `Helm` dan `Botol minum`.

1. Buka tab **Benda**.
2. Isi dua nama kelas.
3. Letakkan objek pertama di dalam kotak tengah kamera.
4. Klik **Rekam kelas 1 · 3 detik**. Ubah sedikit sudut objek selama perekaman.
5. Ulangi untuk objek kedua.
6. Kumpulkan minimal 10 sampel per kelas; disarankan 20–40 sampel per kelas.
7. Klik **LATIH MODEL BENDA**.
8. Tunjukkan salah satu objek di kotak tengah untuk menguji prediksi.

Model benda mengklasifikasikan objek pada area tengah, bukan mendeteksi banyak objek di seluruh gambar. Gunakan latar yang tidak terlalu ramai dan pencahayaan yang cukup.

## 8. Demonstrasi — klasifikasi gestur + stiker dan suara

Contoh kelas: `Telapak terbuka` dan `Tangan mengepal`.

1. Buka tab **Gestur tangan**.
2. Klik **AKTIFKAN PELACAK TANGAN**.
3. Pastikan status pelacak tangan aktif.
4. Peragakan gestur pertama dan klik tombol rekam kelas 1.
5. Rekam gestur kedua.
6. Pastikan kedua kelas memiliki minimal 10 sampel; disarankan 20–40 sampel.
7. Klik **LATIH MODEL GESTUR**.
8. Pastikan kotak **Aktifkan stiker reaksi + efek suara** tercentang.
9. Peragakan gestur yang telah diajarkan. Saat prediksi berpindah ke kelas berbeda dengan skor cukup tinggi, stiker muncul selama sekitar dua detik dan satu SFX pendek diputar.

Stiker/SFX bersifat reaksi antarmuka. Sistem tidak memutar suara berulang-ulang untuk satu gestur yang ditahan di depan kamera. Label yang berisi kata seperti `telapak`, `terbuka`, `open`, `mengep`, `kepal`, `fist`, `jempol`, `thumb`, atau `peace` akan mendapat reaksi yang sesuai; label lain memakai reaksi umum.

File WAV bawaan adalah efek pendek orisinal yang dibuat untuk proyek ini. Letakkan file tersebut di `assets/sfx/` agar audio dapat ditemukan.

## 9. Demonstrasi — klasifikasi ekspresi wajah

Kelas awal: `Senang`, `Sedih`, `Terkejut`, dan `Netral`.

1. Buka tab **Ekspresi wajah**.
2. Klik **AKTIFKAN PELACAK WAJAH**.
3. Posisikan satu wajah di bagian tengah kamera dengan pencahayaan cukup.
4. Peragakan ekspresi `Senang`, lalu klik **Rekam ekspresi 1 · 3 detik**.
5. Ulangi untuk `Sedih`, `Terkejut`, dan `Netral`.
6. Ambil setidaknya 10 sampel untuk masing-masing dari empat kelas. Disarankan 20–40 sampel tiap kelas dengan variasi ringan.
7. Klik **LATIH MODEL EKSPRESI WAJAH**.
8. Uji dengan memperagakan ekspresi yang telah direkam.

Gunakan nama kelas berbeda dan pertahankan nama yang sama sejak pengumpulan sampel hingga training. Model belajar dari volunteer yang melakukan demonstrasi; hasil dapat berbeda antarorang, posisi kamera, pencahayaan, dan cara ekspresi dilakukan. Ini bukan alat diagnosis dan tidak dapat memastikan perasaan seseorang.

## 10. Penyimpanan dan privasi

- Webcam diproses secara lokal oleh aplikasi.
- Aplikasi tidak menyimpan rekaman video atau foto mentah.
- Model hasil training disimpan lokal di folder `models/`.
- Data sampel fitur selama sesi berada di memori aplikasi; gunakan tombol **Hapus sampel dan model** untuk menghapus sampel dalam sesi dan file model terkait.
- Minta persetujuan volunteer sebelum menggunakan webcam dan sebelum memperagakan ekspresi wajah.

File model yang dibuat:

- `models/object_classifier.joblib`
- `models/gesture_classifier.joblib`
- `models/face_classifier.joblib`

## 11. Troubleshooting

### Kamera tidak terdeteksi

- Tutup aplikasi lain yang sedang menggunakan webcam.
- Periksa izin kamera Windows untuk aplikasi desktop.
- Klik **Hubungkan kamera**.

### `ModuleNotFoundError`

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Pastikan VS Code menggunakan interpreter `.venv`.

### Pesan model tangan atau wajah belum tersedia

```powershell
.\.venv\Scripts\python.exe download_models.py
```

### Tangan atau wajah tidak terdeteksi

Dekatkan tangan/wajah ke kamera, pastikan cahaya cukup, dan hindari cahaya sangat kuat dari belakang.

### Tidak ada suara

- Pastikan kotak efek suara dicentang.
- Pastikan volume Windows tidak dalam keadaan mute.
- Pastikan file `assets/sfx/pop.wav`, `boing.wav`, dan `sparkle.wav` ada.
- Efek dipicu ketika hasil prediksi berganti kelas; tahan gestur yang sama tidak mengulang suara terus-menerus.

### Prediksi sering salah

Tambahkan variasi sampel yang jelas dan seimbang. Untuk wajah, usahakan volunteer melihat kamera dan merekam setiap ekspresi dengan pencahayaan yang relatif konsisten. Skor prediksi adalah keluaran model, bukan jaminan akurasi.

## Struktur proyek

```text
TeachableMachinePython/
├── app.py
├── ml_engine.py
├── object_features.py
├── hand_tracker.py
├── face_tracker.py
├── download_models.py
├── download_hand_model.py       # pengunduh model tangan versi lama
├── requirements.txt
├── README.md
├── assets/
│   └── sfx/
│       ├── pop.wav
│       ├── boing.wav
│       └── sparkle.wav
└── models/
    ├── README.txt
    └── (model task dan model hasil training disimpan di sini)
```

## Catatan teknis

- Objek: HOG + histogram warna → SVM dua kelas.
- Tangan: MediaPipe Hand Landmarker (21 titik) → SVM dua kelas.
- Wajah: MediaPipe Face Landmarker (52 skor blendshape) → SVM empat kelas.
- Antarmuka: PySide6; preview webcam: OpenCV; SFX: `QSoundEffect`.
- Versi MediaPipe menggunakan Task API dengan model asset `.task` resmi. Lihat dokumentasi [Hand Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker) dan [Face Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker).
