Folder ini digunakan untuk menyimpan file model.
Jalankan `python download_hand_model.py` untuk mengunduh hand_landmarker.task.
File classifier .joblib dibuat otomatis setelah proses training berhasil.
